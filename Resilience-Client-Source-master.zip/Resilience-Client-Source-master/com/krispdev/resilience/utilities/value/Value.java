package com.krispdev.resilience.utilities.value;

public class Value {
	
	private String name;
	
	public Value(String name){
		this.name = name;
	}
	
	public String getName(){
		return name;
	}
	
}
