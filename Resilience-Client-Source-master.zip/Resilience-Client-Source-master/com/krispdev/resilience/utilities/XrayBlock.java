package com.krispdev.resilience.utilities;

public class XrayBlock {
	
	private int id;
	
	public XrayBlock(int id){
		this.id = id;
	}
	
	public int getId(){
		return id;
	}
	
}
