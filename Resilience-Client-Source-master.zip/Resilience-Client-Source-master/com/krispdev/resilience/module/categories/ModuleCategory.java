package com.krispdev.resilience.module.categories;

public enum ModuleCategory {
	PLAYER,
	MOVEMENT,
	WORLD,
	COMBAT,
	RENDER,
	MISC,
	GUI,
	NONE, 
	COMBAT_EXTENSION
}
