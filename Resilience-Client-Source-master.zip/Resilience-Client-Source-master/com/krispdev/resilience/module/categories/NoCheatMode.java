package com.krispdev.resilience.module.categories;

public enum NoCheatMode {
	COMPATIBLE,
	SEMICOMPATIBLE,
	INCOMPATIBLE,
	VANILLAONLY
}
