package com.krispdev.resilience.event.listeners;

public interface Listener {}
