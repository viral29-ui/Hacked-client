package com.krispdev.resilience.event.events;

public interface Event {
	void onEvent();
}
