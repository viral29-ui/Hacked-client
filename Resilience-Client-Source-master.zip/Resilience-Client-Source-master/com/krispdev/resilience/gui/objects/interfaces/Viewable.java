package com.krispdev.resilience.gui.objects.interfaces;

public interface Viewable {
	
	void draw(int x, int y);
	
}
