package com.krispdev.resilience.interfaces;

public interface Bindable {
	
	void onKeyDown(int keyCode);
	
}
