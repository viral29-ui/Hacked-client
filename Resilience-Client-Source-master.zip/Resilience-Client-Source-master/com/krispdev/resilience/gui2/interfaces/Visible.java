package com.krispdev.resilience.gui2.interfaces;

public interface Visible {
	
	void draw(float x, float y);
	
}
