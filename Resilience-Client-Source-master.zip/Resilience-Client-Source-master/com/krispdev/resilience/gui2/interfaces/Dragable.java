package com.krispdev.resilience.gui2.interfaces;

public interface Dragable {
	
	void drag(float x, float y);
	void updateDrag(float x, float y);
	
}
