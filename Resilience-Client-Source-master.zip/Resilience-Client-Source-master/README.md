# Resilience-Client-Source


Source of the Minecraft Hacked client Resilience

[![Gitter Chat](https://badges.gitter.im/Bluscream/Resilience-Client-Source.png)](https://gitter.im/Bluscream/Resilience-Client-Source)
